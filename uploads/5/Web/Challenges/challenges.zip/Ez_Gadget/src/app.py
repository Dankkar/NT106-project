from flask import Flask, render_template, jsonify, make_response
import os 
from random import random

app = Flask(__name__)

DOCKER_DIRECTORY = "/docker/"
HOST = "http://localhost"
TIMEOUT = 450 # 15 minutes

challenges = [ f.name for f in os.scandir(DOCKER_DIRECTORY) if f.is_dir() ]

@app.route("/")
def index():
    global challenges
    challenges = [ f.name for f in os.scandir(DOCKER_DIRECTORY) if f.is_dir() ]
    return render_template('index.html', challenges=challenges)

@app.route("/start/<challenge_name>")
def start(challenge_name):
    if not challenge_name in challenges:
        return jsonify({"err": True, "result": "challenge not found"})
    
    if os.path.exists(DOCKER_DIRECTORY + challenge_name):
        os.chdir(DOCKER_DIRECTORY + challenge_name)
    else:
        return jsonify({"err": True, "result": "challenge's directory not exists"})
    
    port = round(random()*65536)

    os.environ["APP_PORT"] = str(port)
    ret_val = os.system(f"docker-compose -p {challenge_name}_{port} up -d && (sleep {TIMEOUT} && docker-compose -p {challenge_name}_{port} down all) &")
    print(f"[DEBUG] os.system -> {ret_val}", flush=True)

    resp = make_response(jsonify({"err": False, "result":f"{HOST}:{port}/"}))
    resp.set_cookie("instance", f"{HOST}:{port}/", max_age=TIMEOUT)
    return resp

app.run("0.0.0.0", 5000)