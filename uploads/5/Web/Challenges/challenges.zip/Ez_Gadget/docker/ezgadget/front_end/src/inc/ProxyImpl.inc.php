<?php 

// if (!defined("INTERNAL_INCLUDING")) die("Internal class cannot be required by normal app functions!");

if (!class_exists("ProxyImpl")) {
    class ProxyImpl {
        private $url = "http://back-end:3000";
        private $method = "GET";
        private $headers = [];
        private $data = "";
    
        public function __construct($url = "", $method = "GET", $headers=[], $data="") {
            $this->url = $url;
            $this->method = $method;
            $this->headers = $headers;
            $this->data = $data;
        }
    
        public function __destruct() {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->url.'/garbage_collect');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            if ($this->method !== "GET") {
                curl_setopt($ch, CURLOPT_POST, true);
                if ($this->data) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $this->data);
                }
            } 
            if (count($this->headers)) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
            }
            echo "DESTRUCTING";
            echo curl_exec($ch);
            curl_close($ch);
        }
    }
}

?>