<?php 

if (!defined("APP_INCLUDING")) die("File can't be directly accessed!");

$title = "Homepage";
$content = "Welcome to Freshman CTF";

?>