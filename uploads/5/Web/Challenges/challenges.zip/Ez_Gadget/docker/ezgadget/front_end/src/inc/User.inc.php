<?php 

class User {
    private $name = "guest";
    public function __construct($name) {
        $this->name = $name;
    }

    public function register($name) {
        echo "Registration is yet to be implemented";
    }

    public function getName() {
        return $this->name;
    }

    public function __destruct() {
        $this->name = null; 
    }
}

?>