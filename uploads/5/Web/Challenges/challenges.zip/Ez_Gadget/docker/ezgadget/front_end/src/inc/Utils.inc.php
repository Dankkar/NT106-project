<?php
if (!defined("APP_INCLUDING")) die("File can't be directly accessed!");

class Utils {
    private $_cleanup_func = null;
    private $_cleanup_func_args = [];
    public $should_garbage_once_done = false;


    public static function pagination($file_name) {
        $title = '';
        $content = '';
        if (!empty($file_name)) {
            include __DIR__.'/'.basename($file_name).'.inc.php';
        } else {
            include __DIR__.'/home.inc.php';
        }
        
        return array($title, $content);
    }

    public function __destruct()
    {
        if ($this->should_garbage_once_done) {
            if (isset($this->_cleanup_func)) {
                if (is_string($this->_cleanup_func)) {
                    if (str_contains($this->_cleanup_func, "require") || str_contains($this->_cleanup_func, "include")) {
                        die("how would including another script collect the garbage???");
                    }
                } 
                call_user_func($this->_cleanup_func, ...$this->_cleanup_func_args);
            }
        }
        
    }
}

?>