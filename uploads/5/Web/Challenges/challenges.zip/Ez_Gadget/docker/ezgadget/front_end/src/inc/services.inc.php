<?php 

if (!defined("APP_INCLUDING")) die("File can't be directly accessed!");

$title = "Services";
$content = "Our services is pressing people...";

?>