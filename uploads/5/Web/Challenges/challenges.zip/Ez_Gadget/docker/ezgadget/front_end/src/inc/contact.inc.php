<?php 

if (!defined("APP_INCLUDING")) die("File can't be directly accessed!");

$title = "Contact";
$content = "Wanna know who made this challenge? Message me on discord at <b>shin24_2354</b>";

?>