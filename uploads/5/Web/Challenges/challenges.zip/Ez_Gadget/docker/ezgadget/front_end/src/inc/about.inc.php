<?php 

if (!defined("APP_INCLUDING")) die("File can't be directly accessed!");

$title = "About";
$content = "Freshman is an CTF event for newcomers to show their skills";

?>