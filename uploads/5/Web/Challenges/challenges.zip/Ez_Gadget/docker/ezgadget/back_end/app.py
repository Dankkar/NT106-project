from flask import Flask, request

app = Flask(__name__)

@app.route("/garbage_collect")
def garbage_collect():
    return "Garbage collected"

@app.route("/internal/eval", methods = ['POST', 'GET'])
def internal_eval():
    # evaluating a files with a punch of garbage is painful? i will let you choose which location 
    # to start and how many bytes to evaluate

    if "file" in request.form.keys() and "offset" in request.form.keys() and "length" in request.form.keys():
        with open(request.form["file"], "rb") as f:
            f.seek(int(request.form["offset"], 16))
            data = f.read(int(request.form["length"]))
            print(b"eval: " + data)
            data = data.decode()
            return eval(data)
    return "ERROR"

@app.route("/internal/read", methods = ['POST', 'GET'])
def internal_read():
    return open(request.form["file"]).read()

@app.route("/internal/debug", methods = ['POST', 'GET'])
def internal_debug():
    print(request.form["msg"], flush=True)
    return "for debug only.... or is it?"

app.run("0.0.0.0", 3000)