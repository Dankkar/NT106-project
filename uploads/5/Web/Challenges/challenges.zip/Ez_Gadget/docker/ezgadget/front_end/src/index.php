<?php 
define("APP_INCLUDING", true);
include 'inc/Utils.inc.php';

$utils = new Utils();
include "inc/ProxyImpl.inc.php";

list($title, $content) = $utils->pagination($_GET['page']);

if (isset($_COOKIE['app_cookies'])) {
  $json = json_decode($_COOKIE['app_cookies']);
  if (is_array($json)) {
      foreach ($json as $key => $val) {
        $data[$key] = @unserialize(base64_decode($val->data));
          // if ($val->expire_time <= time()) {
          //   $data[$key]->__destruct();
          // }
      }
  }
}

// {
//   $a = new ProxyImpl();
//   $b = [];
//   for ($i = 0; $i < 99999; $i++) {
//     array_push($b, "aaa");
//   }
// }




?>

<!DOCTYPE html>
<html>
<head>
  <title>Ez Gadget</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <header>
    <h1>Welcome to Freshman CTF</h1>
  </header>

  <nav>
    <ul>
      <li><a href="index.php?page=home">Home</a></li>
      <li><a href="index.php?page=about">About</a></li>
      <li><a href="index.php?page=services">Services</a></li>
      <li><a href="index.php?page=contact">Contact</a></li>
    </ul>
  </nav>

  <section>

    <h2><?= $title ?></h2>
    <p><?=$content ?></p>
  </section>

  <footer>
    <p>&copy; 2023 Shin24. All rights reserved.</p>
  </footer>
</body>
</html>