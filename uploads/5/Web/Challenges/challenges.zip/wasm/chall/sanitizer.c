// emcc sanitizer.c -g2 --no-entry -o sanitizer.js -s EXPORTED_RUNTIME_METHODS=ccall,cwrap -s NO_EXIT_RUNTIME=1

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <emscripten.h>

typedef struct
{
    char * result;
    char raw_str[0x300];
    char blacklist[0x10];
} SanitizeTarget;

EMSCRIPTEN_KEEPALIVE
char * sanitize(char * raw_input, char * blacklist) {
    SanitizeTarget * target = malloc(sizeof(SanitizeTarget));

    target->result = malloc(0x300);
    
    strncpy(target->blacklist, blacklist, 0x10);

    memset(target->result, '\0', 0x300);
    memset(target->raw_str, '\0', 0x300);

    memcpy(target->raw_str, raw_input, 0x300);
    target->raw_str[strlen(raw_input)] = '\x00';

    int j = 0;
    for (short i = 0; i < strlen(target->raw_str); i++) {
        char c = target->raw_str[i];
        if (strchr(target->blacklist, c) == NULL && strchr("()`", c) == NULL) {
            target->result[j] = target->raw_str[i];
            j++;
        }
    }

    return target->result;
}

