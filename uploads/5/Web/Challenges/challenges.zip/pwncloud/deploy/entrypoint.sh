#!/bin/sh
chmod -R 777 /var/www/html
apache2
export USERNAME=$(cat /dev/urandom | head -c 128 | md5sum | head -c 32)
export PASSWORD=$(cat /dev/urandom | head -c 256 | md5sum | head -c 32)
export DIRNAME=$(cat /dev/urandom | head -c 256 | md5sum | head -c 32)

mkdir data$DIRNAME
curl -X POST -s -d "install=true&adminlogin=admin$USERNAME&adminpass=admin$PASSWORD&directory=/var/www/html/data$DIRNAME&dbtype=sqlite" http://localhost > /dev/null
echo $USERNAME
echo $PASSWORD
echo data$DIRNAME

sleep infinity
