#!/bin/bash
if [ ! -d "core" ]; then
    git clone https://github.com/owncloud/core/ -b v5.0.12
else
    echo "core directory exist! aborting..."
fi

if [ ! -d "3rdparty" ]; then
    git clone https://github.com/owncloud-archive/3rdparty -b v5.0.12
else
    echo "3rdparty directory exist! aborting..."
fi

# docker pull owncloud:6.0.6
docker compose up --build